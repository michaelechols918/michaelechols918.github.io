'use babel';

import FakeView from '../lib/fake-view';

describe('FakeView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
